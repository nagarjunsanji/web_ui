'use strict';

// environmnet configuration are added here, below environment function is creaded in modular pattern format
exports.environment = (function () {

  const app = {
    "port": "8081"
  };

  return {
    app: app
  };

})();
