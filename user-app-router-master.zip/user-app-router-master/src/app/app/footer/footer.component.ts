import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {


  constructor(){
    console.log('FooterComponent constructor');
  }

  ngOnInit(){
    console.log('FooterComponent ngOnInit');
  }

}
